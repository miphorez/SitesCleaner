'use strict';
    console.log("hi onlinelife!");  
// var noindex = document.querySelectorAll('iframe');
// for (var i = 0; i < noindex.length; i++) {
//     // console.log(noindex[i].parentNode.removeChild(noindex[i]));  
//     console.log(noindex[i].getAttribute("src"));  
// }

